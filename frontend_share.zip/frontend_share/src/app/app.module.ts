import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { FormsModule }   from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TasklistComponent } from './task/tasklist/tasklist.component';
import { TaskcreateComponent } from './task/taskcreate/taskcreate.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { TaskupdateComponent } from './task/taskupdate/taskupdate.component';
import { HeaderComponent } from './header/header.component';
import { AuthInterceptor } from './auth/auth-intercepter';


@NgModule({
  declarations: [
    AppComponent,
    TasklistComponent,
    TaskcreateComponent,
    LoginComponent,
    SignupComponent,
    TaskupdateComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
