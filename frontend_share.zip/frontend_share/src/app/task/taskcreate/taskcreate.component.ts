import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { TaskService } from '../task.service';

@Component({
  selector: 'app-taskcreate',
  templateUrl: './taskcreate.component.html',
  styleUrls: ['./taskcreate.component.css']
})
export class TaskcreateComponent implements OnInit {

  constructor(public taskService: TaskService) { }

  ngOnInit() {
  }
  onAdd(form:NgForm){
    if(form.invalid){
      return
    }
    console.log(form.value.task);

    this.taskService.add(form.value.task);
  }
}
