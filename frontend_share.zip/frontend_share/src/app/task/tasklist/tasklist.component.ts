import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';
import { Task } from '../task.model';
import { Subscription } from "rxjs";

@Component({
  selector: 'app-tasklist',
  templateUrl: './tasklist.component.html',
  styleUrls: ['./tasklist.component.css']
})
export class TasklistComponent implements OnInit {

  tasks:Task[]=[];
  private tasksSub: Subscription;

  constructor(public taskService: TaskService) { }

  ngOnInit() {
    this.taskService.getTasks();
    this.tasksSub=this.taskService.getTaskUpdateListener()
      .subscribe((tasks)=>{
        this.tasks=tasks.tasks;
      });
  }

  onDelete(taskid:any){
    this.taskService.delete(taskid);
  }

}
