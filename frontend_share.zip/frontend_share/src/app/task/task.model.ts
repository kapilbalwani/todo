export interface Task{
    id:string,
    task:string,
    date:string
}