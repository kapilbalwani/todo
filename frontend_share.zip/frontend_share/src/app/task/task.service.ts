import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { Subject } from "rxjs";

import { Task } from './task.model';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class TaskService {

  public tasks:Task[]=[];
  private tasksUpdated = new Subject<{ tasks: Task[]}>();

  constructor(private http: HttpClient,private router:Router) { }

  getTasks(){
    this.http.get('http://localhost:3000/tasks')
    .pipe(map((taskData:any) => {
        console.log(taskData);
        return {tasks: taskData.map(task => {
            return {
              task: task.task,
              date: task.date,
              id: task._id,
              creator: task.creator
            }
          })}
      }))
      .subscribe((fetchedtasks)=>{
          this.tasks=fetchedtasks.tasks;
          console.log(this.tasks);
          this.tasksUpdated.next({
            tasks:[...this.tasks]
            
          })
    })
  }

  getTaskUpdateListener() {
    return this.tasksUpdated.asObservable();
  }

  getTask(taskid:string){
    return this.http.get<{
      _id: string;
      task: string;
      date: string,
      creator: string;}>("http://localhost:3000/tasks"+"/"+taskid);
      
  }
  add(task:any){
    console.log("Going to addd :"+task);
    const taskData={task:task}
    this.http.post("http://localhost:3000/tasks",taskData)
      .subscribe((message)=>{
        console.log(message);
        this.getTasks();
      })
  }

  delete(taskid:String){
    console.log(taskid);
    this.http.delete("http://localhost:3000/tasks"+"/"+taskid)
      .subscribe((message)=>{
        console.log(message);
        this.getTasks();
      })
  }

  update(taskid:String){
    console.log(taskid);
  }
}
