import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { TaskService } from '../task.service';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Task} from '../task.model';
import { ActivatedRoute, ParamMap } from "@angular/router";

@Component({
  selector: 'app-taskupdate',
  templateUrl: './taskupdate.component.html',
  styleUrls: ['./taskupdate.component.css']
})
export class TaskupdateComponent implements OnInit {

  updatedTask:Task;
  private taskId: string;
  form: FormGroup;
  constructor(public taskService: TaskService,public route: ActivatedRoute,) { }

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has("taskId")) {
        //this.mode = "edit";
        this.taskId = paramMap.get("taskId");
        //this.isLoading = true;
        this.taskService.getTask(this.taskId).subscribe(taskData => {
          //this.isLoading = false;
          this.updatedTask = {
            id: taskData._id,
            task: taskData.task,
            date: taskData.date
          };
          this.form.setValue({
            task: this.updatedTask.task,
          });
        });
      } 
    });
  }
  

}
