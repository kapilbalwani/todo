import { Component, OnInit } from '@angular/core';

import { TaskService } from '../task.service';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Task} from '../task.model';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { AuthService } from 'src/app/auth/auth.service';
import { Subscription } from "rxjs";

@Component({
  selector: 'app-taskupdate',
  templateUrl: './taskupdate.component.html',
  styleUrls: ['./taskupdate.component.css']
})
export class TaskupdateComponent implements OnInit {

  updatedTask:Task;
  private taskId: string;
  form: FormGroup;
  private authStatusSub: Subscription;
  constructor(public taskService: TaskService,public route: ActivatedRoute,private authService: AuthService) { }

  ngOnInit() {

    this.authStatusSub = this.authService
      .getAuthStatusListener()
      .subscribe(authStatus => {
        
      });
    this.form = new FormGroup({
      task: new FormControl(null, {
        validators: [Validators.required]
      })
    });

    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      console.log(paramMap);
      if (paramMap.has("taskid")) {
        
        this.taskId = paramMap.get("taskid");
        console.log(this.taskId);
        this.taskService.getTask(this.taskId).subscribe(taskData => {
          
          this.updatedTask = {
            id: taskData._id,
            task: taskData.task,
            date: taskData.date
          };
          console.log(this.updatedTask);
          this.form.setValue({
            task: this.updatedTask.task,
          });
        });
      } 
    });
  }

  onUpdate(){

    this.taskService.update(
      this.taskId,
      this.form.value.task
    );
  }
  

}
