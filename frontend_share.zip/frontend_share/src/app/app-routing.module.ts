import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TasklistComponent } from './task/tasklist/tasklist.component';
import { TaskcreateComponent } from './task/taskcreate/taskcreate.component';
import { TaskupdateComponent } from './task/taskupdate/taskupdate.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  {path:"",component:LoginComponent},
  {path:"taskscreate",component:TaskcreateComponent,canActivate:[AuthGuard]},
  {path: "tasklist",component:TasklistComponent,canActivate:[AuthGuard]},
  {path:"edit/:taskid",component:TaskupdateComponent,canActivate:[AuthGuard]},
  { path: "auth/login", component: LoginComponent },
  { path: "auth/signup", component: SignupComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{onSameUrlNavigation: 'reload'})],
  exports: [RouterModule],
  providers:[AuthGuard]
})
export class AppRoutingModule { }
